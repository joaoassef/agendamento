export default function AdminPage() {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-4">Bem-vindo ao Painel Administrativo</h2>
      <p className="text-gray-700">
        Selecione uma opção no menu lateral para começar.
      </p>
    </div>
  );
}

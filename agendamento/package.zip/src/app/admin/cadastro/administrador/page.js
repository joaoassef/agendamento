export default function PageCadastroAdministrador() {
    return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Cadastro de Administrador</h1>
      <p>Em breve, formulário de cadastro de administrador...</p>
    </div>
  );
}

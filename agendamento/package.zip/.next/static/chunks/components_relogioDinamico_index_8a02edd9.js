(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/components/relogioDinamico/index.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "RelogioDinamico": (()=>RelogioDinamico)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
function RelogioDinamico() {
    _s();
    const [dataHora, setDataHora] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(getCurrentDateTime());
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "RelogioDinamico.useEffect": ()=>{
            const interval = setInterval({
                "RelogioDinamico.useEffect.interval": ()=>{
                    setDataHora(getCurrentDateTime());
                }
            }["RelogioDinamico.useEffect.interval"], 1000);
            return ({
                "RelogioDinamico.useEffect": ()=>clearInterval(interval)
            })["RelogioDinamico.useEffect"];
        }
    }["RelogioDinamico.useEffect"], []);
    function getCurrentDateTime() {
        const now = new Date();
        const dia = now.getDate();
        const ano = now.getFullYear();
        const hora = now.toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
        // Array com nomes dos meses
        const meses = [
            'janeiro',
            'fevereiro',
            'março',
            'abril',
            'maio',
            'junho',
            'julho',
            'agosto',
            'setembro',
            'outubro',
            'novembro',
            'dezembro'
        ];
        const mesPorExtenso = meses[now.getMonth()];
        return `${dia} de ${mesPorExtenso} de ${ano} - ${hora}`;
    }
    return {
        dataHora
    };
}
_s(RelogioDinamico, "c46b0BJEMzymPC/Uu6q3KE6PkHQ=");
_c = RelogioDinamico;
var _c;
__turbopack_context__.k.register(_c, "RelogioDinamico");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=components_relogioDinamico_index_8a02edd9.js.map
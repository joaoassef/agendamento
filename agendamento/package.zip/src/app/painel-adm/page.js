'use client';
import { Login } from "../../../components/login";

export default function PainelAdm() {
    return (

        <div>
            <Login />
        </div>


    )}
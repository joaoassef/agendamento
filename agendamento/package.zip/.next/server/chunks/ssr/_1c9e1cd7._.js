module.exports = {

"[project]/src/app/admin/cadastro/agendamento/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>PageCadastroAgendamento)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
'use client';
;
;
function PageCadastroAgendamento() {
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        cpf: '',
        nome: '',
        email: '',
        dataNascimento: '',
        tipoExameId: '',
        tipoExame: {
            id: '',
            nome: '',
            descricao: '',
            duracaoPadrao: '',
            instrucoesPreparo: '',
            ativo: true
        },
        dataHoraExame: ''
    });
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [cpfInvalido, setCpfInvalido] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const formatCPF = (value)=>{
        return value.replace(/\D/g, '').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    };
    const unmaskCPF = (value)=>value.replace(/\D/g, '');
    const isValidCPF = (cpf)=>{
        cpf = unmaskCPF(cpf);
        if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;
        let sum = 0;
        for(let i = 0; i < 9; i++)sum += parseInt(cpf.charAt(i)) * (10 - i);
        let firstCheck = sum * 10 % 11;
        if (firstCheck === 10 || firstCheck === 11) firstCheck = 0;
        if (firstCheck !== parseInt(cpf.charAt(9))) return false;
        sum = 0;
        for(let i = 0; i < 10; i++)sum += parseInt(cpf.charAt(i)) * (11 - i);
        let secondCheck = sum * 10 % 11;
        if (secondCheck === 10 || secondCheck === 11) secondCheck = 0;
        return secondCheck === parseInt(cpf.charAt(10));
    };
    const handleChange = (e)=>{
        const { name, value } = e.target;
        if (name.startsWith('tipoExame.')) {
            const field = name.split('.')[1];
            setFormData((prev)=>({
                    ...prev,
                    tipoExame: {
                        ...prev.tipoExame,
                        [field]: value
                    }
                }));
            return;
        }
        if (name === 'cpf') {
            const maskedCPF = formatCPF(value);
            setFormData((prev)=>({
                    ...prev,
                    cpf: maskedCPF
                }));
            setCpfInvalido(false);
        } else {
            setFormData((prev)=>({
                    ...prev,
                    [name]: value
                }));
        }
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (!isValidCPF(formData.cpf)) {
            setCpfInvalido(true);
            setStatus('❌ CPF inválido.');
            return;
        }
        const duracaoFormatada = formData.tipoExame.duracaoPadrao.length === 5 ? formData.tipoExame.duracaoPadrao + ':00' : formData.tipoExame.duracaoPadrao;
        const dataHoraFormatada = formData.dataHoraExame.length === 16 ? formData.dataHoraExame + ':00' : formData.dataHoraExame;
        const payload = {
            Id: 0,
            CPF: unmaskCPF(formData.cpf),
            Nome: formData.nome.trim(),
            Email: formData.email.trim(),
            DataNascimento: formData.dataNascimento,
            TipoExameId: Number(formData.tipoExameId),
            TipoExame: {
                Id: Number(formData.tipoExame.id),
                Nome: formData.tipoExame.nome.trim(),
                Descricao: formData.tipoExame.descricao.trim(),
                DuracaoPadrao: duracaoFormatada,
                InstrucoesPreparo: formData.tipoExame.instrucoesPreparo.trim(),
                Ativo: formData.tipoExame.ativo === 'true' || formData.tipoExame.ativo === true
            },
            DataHoraExame: dataHoraFormatada,
            Cancelado: false,
            Comparecimento: false
        };
        try {
            const response = await fetch('/api/proxy/agendamento', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(payload)
            });
            if (!response.ok) {
                const errorText = await response.text();
                console.error('Resposta do backend:', errorText);
                throw new Error('Erro ao salvar o agendamento');
            }
            setStatus('✅ Agendamento realizado com sucesso!');
            setCpfInvalido(false);
            setFormData({
                cpf: '',
                nome: '',
                email: '',
                dataNascimento: '',
                tipoExameId: '',
                tipoExame: {
                    id: '',
                    nome: '',
                    descricao: '',
                    duracaoPadrao: '',
                    instrucoesPreparo: '',
                    ativo: true
                },
                dataHoraExame: ''
            });
        } catch (error) {
            console.error('Erro ao realizar o agendamento:', error.message);
            setStatus('❌ Erro ao realizar o agendamento.');
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "p-8 bg-white rounded shadow-md max-w-2xl mx-auto",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "text-2xl font-bold mb-6 text-blue-900",
                children: "Cadastro de Agendamento"
            }, void 0, false, {
                fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                lineNumber: 157,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleSubmit,
                className: "space-y-5",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        name: "cpf",
                        value: formData.cpf,
                        onChange: handleChange,
                        placeholder: "CPF",
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 159,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        name: "nome",
                        value: formData.nome,
                        onChange: handleChange,
                        placeholder: "Nome completo",
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 160,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "email",
                        name: "email",
                        value: formData.email,
                        onChange: handleChange,
                        placeholder: "Email",
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 161,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "date",
                        name: "dataNascimento",
                        value: formData.dataNascimento,
                        onChange: handleChange,
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 162,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "number",
                        name: "tipoExameId",
                        value: formData.tipoExameId,
                        onChange: handleChange,
                        placeholder: "ID do Tipo de Exame",
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 163,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "number",
                        name: "tipoExame.id",
                        value: formData.tipoExame.id,
                        onChange: handleChange,
                        placeholder: "ID do Exame",
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 164,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        name: "tipoExame.nome",
                        value: formData.tipoExame.nome,
                        onChange: handleChange,
                        placeholder: "Nome do Exame",
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 165,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        name: "tipoExame.descricao",
                        value: formData.tipoExame.descricao,
                        onChange: handleChange,
                        placeholder: "Descrição",
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "time",
                        step: "1",
                        name: "tipoExame.duracaoPadrao",
                        value: formData.tipoExame.duracaoPadrao,
                        onChange: handleChange,
                        placeholder: "Duração Padrão",
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "text",
                        name: "tipoExame.instrucoesPreparo",
                        value: formData.tipoExame.instrucoesPreparo,
                        onChange: handleChange,
                        placeholder: "Instruções de Preparo",
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 168,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        name: "tipoExame.ativo",
                        value: formData.tipoExame.ativo,
                        onChange: handleChange,
                        className: "border w-full p-2 rounded",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "true",
                                children: "Ativo"
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                                lineNumber: 170,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "false",
                                children: "Inativo"
                            }, void 0, false, {
                                fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                                lineNumber: 171,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 169,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        type: "datetime-local",
                        name: "dataHoraExame",
                        value: formData.dataHoraExame,
                        onChange: handleChange,
                        required: true,
                        className: "border w-full p-2 rounded"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 173,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "submit",
                        className: "bg-blue-700 hover:bg-blue-600 text-white py-2 px-4 rounded w-full",
                        children: "Cadastrar Agendamento"
                    }, void 0, false, {
                        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                        lineNumber: 174,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                lineNumber: 158,
                columnNumber: 7
            }, this),
            status && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `mt-4 font-medium ${status.includes('Erro') || status.includes('inválido') ? 'text-red-600' : 'text-green-600'}`,
                children: status
            }, void 0, false, {
                fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
                lineNumber: 177,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/admin/cadastro/agendamento/page.js",
        lineNumber: 156,
        columnNumber: 5
    }, this);
}
}}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
"use strict";
module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}}),

};

//# sourceMappingURL=_1c9e1cd7._.js.map
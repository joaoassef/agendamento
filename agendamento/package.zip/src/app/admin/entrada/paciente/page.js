export default function EntradaPaciente() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Entrada de Paciente</h1>
      <p>Em breve, formulário de entrada de paciente...</p>
    </div>
  );
}
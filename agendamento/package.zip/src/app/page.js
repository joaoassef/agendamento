"use client";
import Image from "next/image";
import { Login } from "../../components/login";
import PaginaInicial from "./home/page";

export default function Home() {
  return (
    <div>
        <PaginaInicial />
    </div>
  );
}

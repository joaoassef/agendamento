export default function CadastroExames() {
  return (
    <div className="p-6">
      <h1 className="text-xl font-bold">Cadastro de Exames</h1>
      <p>Em breve, formulário de cadastro de exames...</p>
    </div>
  );
}
module.exports = {

"[project]/src/app/admin/layout.js [app-rsc] (ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const e = new Error(`Could not parse module '[project]/src/app/admin/layout.js'

Expression expected`);
e.code = 'MODULE_UNPARSEABLE';
throw e;}}),

};